from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import pandas as pd
import numpy as np
import os
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler, KBinsDiscretizer
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
import io
import base64
from kmodes.kmodes import KModes
import warnings

warnings.filterwarnings('ignore')

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.config['UPLOAD_FOLDER'] = 'uploads'

# Crear carpeta de subida
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Configurar estilo de seaborn
sns.set_theme(style="whitegrid", palette="viridis")

# Variable global para almacenar datos
global_df = None


def convert_numpy_types(obj):
    """
    Convierte tipos de numpy a tipos nativos de Python para serialización JSON
    """
    if isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float32, np.float64)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif isinstance(obj, tuple):
        return tuple(convert_numpy_types(item) for item in obj)
    else:
        return obj


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    global global_df

    if 'file' not in request.files:
        flash('No se seleccionó ningún archivo', 'error')
        return redirect(request.url)

    file = request.files['file']

    if file.filename == '':
        flash('No se seleccionó ningún archivo', 'error')
        return redirect(request.url)

    if file and file.filename.endswith('.csv'):
        try:
            # Leer el CSV, considerando '?' como valores faltantes
            df = pd.read_csv(file, na_values=['?', ''])

            # Reemplazar espacios vacíos con NaN
            df = df.replace(r'^\s*$', np.nan, regex=True)

            global_df = df.copy()
            flash('Archivo cargado exitosamente', 'success')
            return redirect(url_for('results'))
        except Exception as e:
            flash(f'Error al cargar el archivo: {str(e)}', 'error')
            return redirect(url_for('index'))
    else:
        flash('Por favor, suba un archivo CSV válido', 'error')
        return redirect(url_for('index'))


@app.route('/results')
def results():
    return render_template('results.html')


@app.route('/api/view_data')
def view_data():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    # Convertir DataFrame a HTML
    data_html = global_df.to_html(classes='table table-striped', index=False)

    # Información básica del dataset
    info = {
        'filas': int(global_df.shape[0]),
        'columnas': int(global_df.shape[1]),
        'tipos_datos': global_df.dtypes.astype(str).to_dict(),
        'valores_faltantes': convert_numpy_types(global_df.isnull().sum().to_dict())
    }

    return jsonify({
        'data_html': data_html,
        'info': info
    })


@app.route('/api/normalize')
def normalize_data():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Solo normalizar columnas numéricas
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    if not numeric_cols:
        return jsonify({'error': 'No hay columnas numéricas para normalizar'})

    # Guardar estado original
    original_df = df[numeric_cols].copy()

    # Aplicar normalización Min-Max
    scaler = MinMaxScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    # Crear tabla comparativa
    comparison_data = []
    for col in numeric_cols:
        for i in range(min(5, len(df))):
            original_val = original_df.iloc[i][col]
            normalized_val = df.iloc[i][col]

            comparison_data.append({
                'columna': col,
                'original': float(round(original_val, 4)) if not pd.isna(original_val) else 'NaN',
                'normalizado': float(round(normalized_val, 4)) if not pd.isna(normalized_val) else 'NaN'
            })

    # Actualizar DataFrame global
    global_df = df

    return jsonify({
        'message': 'Datos normalizados exitosamente',
        'comparison': convert_numpy_types(comparison_data),
        'columnas_normalizadas': numeric_cols
    })


@app.route('/api/discretize')
def discretize_data():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Solo discretizar columnas numéricas
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    if not numeric_cols:
        return jsonify({'error': 'No hay columnas numéricas para discretizar'})

    # Guardar estado original
    original_df = df[numeric_cols].copy()

    # Aplicar discretización (3 bins)
    discretizer = KBinsDiscretizer(n_bins=3, encode='ordinal', strategy='uniform')
    df[numeric_cols] = discretizer.fit_transform(df[numeric_cols])

    # Crear tabla comparativa
    comparison_data = []
    for col in numeric_cols:
        for i in range(min(5, len(df))):
            original_val = original_df.iloc[i][col]
            discretized_val = df.iloc[i][col]

            comparison_data.append({
                'columna': col,
                'original': float(round(original_val, 4)) if not pd.isna(original_val) else 'NaN',
                'discretizado': int(discretized_val) if not pd.isna(discretized_val) else 'NaN'
            })

    # Actualizar DataFrame global
    global_df = df

    return jsonify({
        'message': 'Datos discretizados exitosamente',
        'comparison': convert_numpy_types(comparison_data),
        'columnas_discretizadas': numeric_cols
    })


@app.route('/api/fill_missing')
def fill_missing():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Contar valores faltantes antes
    missing_before = df.isnull().sum().sum()

    if missing_before == 0:
        return jsonify({'message': 'No hay valores faltantes en el dataset'})

    # Estrategias diferentes para numéricos y categóricos
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()

    # Guardar estado original para mostrar cambios
    original_df = df.copy()

    # Rellenar numéricos con la mediana
    if numeric_cols:
        numeric_imputer = SimpleImputer(strategy='median')
        df[numeric_cols] = numeric_imputer.fit_transform(df[numeric_cols])

    # Rellenar categóricos con la moda
    if categorical_cols:
        categorical_imputer = SimpleImputer(strategy='most_frequent')
        df[categorical_cols] = categorical_imputer.fit_transform(df[categorical_cols])

    # Contar valores faltantes después
    missing_after = df.isnull().sum().sum()

    # Crear tabla de cambios
    changes = []
    for col in df.columns:
        if original_df[col].isnull().sum() > 0:
            changes.append({
                'columna': col,
                'tipo': 'Numérica' if col in numeric_cols else 'Categórica',
                'valores_faltantes_antes': int(original_df[col].isnull().sum()),
                'valores_faltantes_despues': int(df[col].isnull().sum())
            })

    # Actualizar DataFrame global
    global_df = df

    return jsonify({
        'message': f'Valores faltantes rellenados: {int(missing_before)} → {int(missing_after)}',
        'changes': convert_numpy_types(changes),
        'total_faltantes_antes': int(missing_before),
        'total_faltantes_despues': int(missing_after)
    })


@app.route('/api/decision_tree')
def decision_tree():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Eliminar filas con valores faltantes para el árbol de decisión
    df_clean = df.dropna()

    if len(df_clean) < 2:
        return jsonify({'error': 'No hay suficientes datos sin valores faltantes para construir el árbol'})

    # La última columna se usa como objetivo (clase)
    target_col = df_clean.columns[-1]
    X = df_clean.iloc[:, :-1]
    y = df_clean[target_col]

    # Codificar variables categóricas
    le = LabelEncoder()
    categorical_cols = X.select_dtypes(include=['object']).columns

    for col in categorical_cols:
        X[col] = le.fit_transform(X[col])

    y_encoded = le.fit_transform(y) if y.dtype == 'object' else y

    # Construir árbol de decisión con profundidad limitada para mejor visualización
    dt = DecisionTreeClassifier(max_depth=4, random_state=42)
    dt.fit(X, y_encoded)

    # Crear visualización del árbol con mejoras
    plt.figure(figsize=(20, 12))
    plot_tree(dt,
              feature_names=X.columns.tolist(),
              class_names=[str(c) for c in le.classes_] if y.dtype == 'object' else [str(c) for c in np.unique(y)],
              filled=True,
              rounded=True,
              fontsize=10,
              proportion=True,
              impurity=False,
              node_ids=True)

    plt.title('Árbol de Decisión - Visualización Completa', fontsize=16, pad=20)
    plt.tight_layout()

    # Guardar imagen en base64
    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight', dpi=150)
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()

    # Información adicional del árbol
    n_nodes = dt.tree_.node_count
    children_left = dt.tree_.children_left
    children_right = dt.tree_.children_right
    feature = dt.tree_.feature
    threshold = dt.tree_.threshold

    # Generar información paso a paso
    steps = []
    node_depth = np.zeros(shape=n_nodes, dtype=np.int64)
    is_leaves = np.zeros(shape=n_nodes, dtype=bool)
    stack = [(0, -1)]  # (node_id, parent_depth)

    while len(stack) > 0:
        node_id, parent_depth = stack.pop()
        node_depth[node_id] = parent_depth + 1

        # Si es un nodo de división
        if children_left[node_id] != children_right[node_id]:
            stack.append((children_left[node_id], parent_depth + 1))
            stack.append((children_right[node_id], parent_depth + 1))
            feature_name = X.columns[feature[node_id]]
            step_info = {
                'nodo': int(node_id),
                'tipo': 'División',
                'profundidad': int(node_depth[node_id]),
                'condicion': f"{feature_name} <= {float(threshold[node_id]):.2f}",
                'descripcion': f"El nodo {node_id} divide los datos usando '{feature_name}'"
            }
        else:
            is_leaves[node_id] = True
            step_info = {
                'nodo': int(node_id),
                'tipo': 'Hoja',
                'profundidad': int(node_depth[node_id]),
                'condicion': 'Nodo final',
                'descripcion': f"El nodo {node_id} es una hoja (decisión final)"
            }
        steps.append(step_info)

    # Ordenar pasos por nodo
    steps.sort(key=lambda x: x['nodo'])

    # Información de características importantes
    feature_importance = list(zip(X.columns, dt.feature_importances_))
    feature_importance.sort(key=lambda x: x[1], reverse=True)

    # Convertir todos los valores numpy a tipos nativos de Python
    hojas = int(np.sum(is_leaves))
    nodos_totales = int(n_nodes)

    # Preparar datos para respuesta
    response_data = {
        'message': 'Árbol de decisión generado exitosamente',
        'plot_url': f'data:image/png;base64,{plot_url}',
        'caracteristicas': X.columns.tolist(),
        'objetivo': target_col,
        'profundidad': int(dt.get_depth()),
        'muestras': int(len(X)),
        'pasos': convert_numpy_types(steps),
        'importancia_caracteristicas': [
            {'caracteristica': feat, 'importancia': float(round(imp, 4))}
            for feat, imp in feature_importance if imp > 0
        ],
        'nodos_totales': nodos_totales,
        'hojas': hojas
    }

    return jsonify(convert_numpy_types(response_data))


@app.route('/api/kmeans')
def kmeans_clustering():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Solo usar columnas numéricas para K-Means
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    if len(numeric_cols) < 2:
        return jsonify({'error': 'Se necesitan al menos 2 columnas numéricas para K-Means'})

    # Eliminar filas con valores faltantes
    df_clean = df[numeric_cols].dropna()

    if len(df_clean) < 2:
        return jsonify({'error': 'No hay suficientes datos sin valores faltantes para K-Means'})

    # Aplicar K-Means (2 clusters como en el ejemplo)
    kmeans = KMeans(n_clusters=2, random_state=42)
    clusters = kmeans.fit_predict(df_clean)

    # Calcular centroides
    centroids = kmeans.cluster_centers_

    # Crear gráfico de clusters (usando las dos primeras dimensiones)
    plt.figure(figsize=(10, 6))

    if len(numeric_cols) >= 2:
        plt.scatter(df_clean.iloc[:, 0], df_clean.iloc[:, 1], c=clusters, cmap='viridis', s=50, alpha=0.7)
        plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='X', s=200, label='Centroides')
        plt.xlabel(numeric_cols[0])
        plt.ylabel(numeric_cols[1])
        plt.title('Resultado de K-Means Clustering')
        plt.legend()
    else:
        # Si solo hay una dimensión, usar histograma
        plt.hist([df_clean[clusters == 0].iloc[:, 0], df_clean[clusters == 1].iloc[:, 0]],
                 bins=20, alpha=0.7, label=['Cluster 0', 'Cluster 1'])
        plt.axvline(centroids[0, 0], color='blue', linestyle='--', label='Centroide 0')
        plt.axvline(centroids[1, 0], color='orange', linestyle='--', label='Centroide 1')
        plt.xlabel(numeric_cols[0])
        plt.ylabel('Frecuencia')
        plt.title('Resultado de K-Means Clustering')
        plt.legend()

    # Guardar imagen en base64
    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()

    # Preparar datos para mostrar
    results_data = []
    for i in range(min(10, len(df_clean))):
        result_row = {
            'indice': int(i),
            'cluster': int(clusters[i])
        }
        for j, col in enumerate(numeric_cols):
            result_row[col] = float(round(df_clean.iloc[i, j], 4))
        results_data.append(result_row)

    # Información de centroides
    centroids_info = []
    for i, centroid in enumerate(centroids):
        centroid_data = {'cluster': int(i)}
        for j, col in enumerate(numeric_cols):
            centroid_data[col] = float(round(centroid[j], 4))
        centroids_info.append(centroid_data)

    # Aplicar conversión de tipos numpy
    response_data = {
        'message': 'K-Means aplicado exitosamente',
        'plot_url': f'data:image/png;base64,{plot_url}',
        'results': convert_numpy_types(results_data),
        'centroids': convert_numpy_types(centroids_info),
        'num_clusters': 2
    }

    return jsonify(response_data)


@app.route('/api/kmodes')
def kmodes_clustering():
    global global_df
    if global_df is None:
        return jsonify({'error': 'No hay datos cargados'})

    df = global_df.copy()

    # Solo usar columnas categóricas para K-Modes
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()

    if len(categorical_cols) < 1:
        return jsonify({'error': 'Se necesitan columnas categóricas para K-Modes'})

    # Eliminar filas con valores faltantes
    df_clean = df[categorical_cols].dropna()

    if len(df_clean) < 2:
        return jsonify({'error': 'No hay suficientes datos sin valores faltantes para K-Modes'})

    # Aplicar K-Modes (2 clusters como en el ejemplo)
    kmodes = KModes(n_clusters=2, init='Huang', random_state=42)
    clusters = kmodes.fit_predict(df_clean)

    # Obtener modas (centroides categóricos)
    modes = kmodes.cluster_centroids_

    # Preparar datos para mostrar
    results_data = []
    for i in range(min(10, len(df_clean))):
        result_row = {
            'indice': int(i),
            'cluster': int(clusters[i])
        }
        for col in categorical_cols:
            result_row[col] = df_clean.iloc[i][col]
        results_data.append(result_row)

    # Información de modas
    modes_info = []
    for i, mode in enumerate(modes):
        mode_data = {'cluster': int(i)}
        for j, col in enumerate(categorical_cols):
            mode_data[col] = mode[j]
        modes_info.append(mode_data)

    # Aplicar conversión de tipos numpy
    response_data = {
        'message': 'K-Modes aplicado exitosamente',
        'results': convert_numpy_types(results_data),
        'modes': convert_numpy_types(modes_info),
        'num_clusters': 2,
        'costo': float(kmodes.cost_)
    }

    return jsonify(response_data)


if __name__ == '__main__':
    app.run(debug=True)